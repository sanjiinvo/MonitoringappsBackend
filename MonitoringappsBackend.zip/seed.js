// seed.js
const { User, Role, Department } = require('./models/models');
const bcrypt = require('bcrypt');

async function seedDatabase() {
    try {
        // Создание ролей
        const roles = ['Admin', 'Moder', 'User'];
        for (const role of roles) {
            await Role.findOrCreate({
                where: { roleName: role }
            });
        }

        // Создание отдела
        const [itDepartment, created] = await Department.findOrCreate({
            where: { departmentName: 'IT' },
        });

        // Получение ID роли "admin"
        const adminRole = await Role.findOne({ where: { roleName: 'Admin' } });

        // Создание пользователя-администратора
        await User.findOrCreate({
            where: { username: 'sanzh' },
            defaults: {
                rlname: 'Admin User',
                password: bcrypt.hashSync('sanzh', 10),
                roleId: adminRole.id,
                departmentId: itDepartment.id
            }
        });

        console.log('База данных успешно инициализирована начальными данными.');
    } catch (error) {
        console.error('Ошибка при инициализации данных:', error);
    }
}

// Вызов функции и завершение процесса после выполнения
seedDatabase().then(() => {
    console.log('Сеединг завершен.');
    process.exit();
}).catch(error => {
    console.error('Ошибка при выполнении сеединга:', error);
    process.exit(1);
});
